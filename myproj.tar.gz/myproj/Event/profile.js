let profile = {
    registrar: {
        "wallet": "../vars/profiles/vscode/wallets/registrar.property.com",
        "ccp": "../vars/profiles/propertychannel_connection_for_nodesdk.json"
    },
    user: {
        "wallet": "../vars/profiles/vscode/wallets/user.property.com",
        "ccp": "../vars/profiles/propertychannel_connection_for_nodesdk.json"
    }
}

module.exports = { profile }
